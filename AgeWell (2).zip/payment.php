<html>
    <body>
        <form method="POST" action="confirm.php">
        Card No <input type="text" name="card_no" style="margin-left:50px;"> <br> <br>
        Security Code <input type="text" name="security_code" style="margin-left:20px;"> <br> <br>
        <input type="submit" value="Submit" style="background-color:orange;color:white;border-color:orange;margin-left:120px;">
        </form>
    </body>
</html>